import SoundIcon from './SoundIcon'
export default SoundIcon
