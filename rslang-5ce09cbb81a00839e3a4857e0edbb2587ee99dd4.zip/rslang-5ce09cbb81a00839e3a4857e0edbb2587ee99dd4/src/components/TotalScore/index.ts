import TotalScore from './TotalScore'
export default TotalScore
