import WordsListAudio from './WordsListAudio'
export default WordsListAudio
