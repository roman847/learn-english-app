import GameResults from './GameResults'
export default GameResults
