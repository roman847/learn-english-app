import ExitButton from './ExitButton'
export default ExitButton
