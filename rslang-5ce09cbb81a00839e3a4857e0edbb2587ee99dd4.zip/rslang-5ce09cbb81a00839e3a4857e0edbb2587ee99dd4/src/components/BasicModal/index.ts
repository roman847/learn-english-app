import BasicModal from './BasicModal'
export default BasicModal
