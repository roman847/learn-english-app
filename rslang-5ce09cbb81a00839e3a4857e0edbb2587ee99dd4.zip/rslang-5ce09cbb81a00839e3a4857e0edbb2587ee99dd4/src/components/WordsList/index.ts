import WordsList from './WordsList'
export default WordsList
