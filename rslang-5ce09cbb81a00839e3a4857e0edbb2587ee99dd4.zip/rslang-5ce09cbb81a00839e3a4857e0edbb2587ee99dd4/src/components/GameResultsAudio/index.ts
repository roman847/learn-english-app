import GameResultsAudio from './GameResultsAudio'
export default GameResultsAudio
