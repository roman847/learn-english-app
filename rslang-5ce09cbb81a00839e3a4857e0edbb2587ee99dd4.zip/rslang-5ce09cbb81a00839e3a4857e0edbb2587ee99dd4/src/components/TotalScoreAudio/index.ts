import TotalScoreAudio from './TotalScoreAudio'
export default TotalScoreAudio
