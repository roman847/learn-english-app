import ZoomIcon from './ZoomIcon'
export default ZoomIcon
