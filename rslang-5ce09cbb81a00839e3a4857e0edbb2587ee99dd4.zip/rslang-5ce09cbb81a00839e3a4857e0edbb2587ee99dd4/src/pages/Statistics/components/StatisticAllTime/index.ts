import StatisticAllTime from './StatisticAllTime'
export default StatisticAllTime
