import React from 'react'

import style from './diagram.module.scss'

const Diagram = () => {
  return (
    <div>
      <div className={style.container__diagram}></div>
    </div>
  )
}

export default Diagram
