import Diagram from './Diagram'
export default Diagram
