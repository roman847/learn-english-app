import VolumeIcon from './VolumeIcon'
export default VolumeIcon
