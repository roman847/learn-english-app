import GameContent from './GameContent'
export default GameContent
