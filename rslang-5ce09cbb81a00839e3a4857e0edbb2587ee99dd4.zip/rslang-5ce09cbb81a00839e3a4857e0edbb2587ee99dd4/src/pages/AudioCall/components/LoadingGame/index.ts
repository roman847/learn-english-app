import LoadingGame from './LoadingGame'
export default LoadingGame
