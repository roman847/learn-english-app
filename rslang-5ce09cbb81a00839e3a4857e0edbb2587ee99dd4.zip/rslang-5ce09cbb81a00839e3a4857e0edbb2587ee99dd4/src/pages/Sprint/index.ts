import Sprint from './Sprint'
export default Sprint
