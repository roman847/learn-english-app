import WatchIcon from './WatchIcon'
export default WatchIcon
