import SprintGeneral from './SprintGeneral'
export default SprintGeneral
