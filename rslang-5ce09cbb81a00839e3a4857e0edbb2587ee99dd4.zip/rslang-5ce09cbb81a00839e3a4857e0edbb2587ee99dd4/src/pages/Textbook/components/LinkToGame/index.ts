import LinkToGame from 'pages/Textbook/components/LinkToGame/LinkToGame'
export default LinkToGame
