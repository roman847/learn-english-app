import DifficultWords from 'pages/Textbook/components/DifficultWords/DifficultWords'
export default DifficultWords
