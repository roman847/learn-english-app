import WordItem from 'pages/Textbook/components/WordItem/WordItem'
export default WordItem
