import Opportunities from './Opportunities'
export default Opportunities
