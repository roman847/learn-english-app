import MainContent from './MainContent'
export default MainContent
