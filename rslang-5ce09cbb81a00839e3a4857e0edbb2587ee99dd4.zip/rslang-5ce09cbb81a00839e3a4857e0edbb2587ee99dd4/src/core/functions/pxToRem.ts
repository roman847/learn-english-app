const pxToRem = (px: number) => `${px / 16}rem`

export default pxToRem
