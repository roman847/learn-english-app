const getRandomIndex = (max: number) => {
  return Math.floor(Math.random() * max)
}
export default getRandomIndex
