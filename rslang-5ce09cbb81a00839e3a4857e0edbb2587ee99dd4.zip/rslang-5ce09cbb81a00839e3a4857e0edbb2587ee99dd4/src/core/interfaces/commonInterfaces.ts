export type ServerError = { errorMessage: string }
